 
import sentencepiece as spm
import json
from tqdm import tqdm
 
def preprocess_ru(src_list,sp_path_src):
    sp_src = spm.SentencePieceProcessor()
    sp_src.load(sp_path_src)
 
    for i, text in enumerate(tqdm(src_list)):
        text = ' '.join(sp_src.encode(text, out_type=str))
        src_list[i] = "<ru> <v7> "+text + "\n"
    #import pdb; pdb.set_trace()
    with open("ru_tokenized.txt","w+") as f:
        f.writelines(src_list)
 
with open ("ru.txt") as f:
   src_list = f.readlines()
   preprocess_ru(src_list,"ru.model")
   
def preprocess_ab(src_list,sp_path_src):
    sp_src = spm.SentencePieceProcessor()
    sp_src.load(sp_path_src)
 
    for i, text in enumerate(tqdm(src_list)):
        text = ' '.join(sp_src.encode(text, out_type=str))
        src_list[i] = text + "\n"
    #import pdb; pdb.set_trace()
    with open("ab_tokenized.txt","w+") as f:
        f.writelines(src_list)
 
with open ("ab.txt") as f:
   src_list = f.readlines()
   preprocess_ab(src_list,"ab.model")
